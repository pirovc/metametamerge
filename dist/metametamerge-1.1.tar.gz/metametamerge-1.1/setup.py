from distutils.core import setup
setup(name='metametamerge',
      author='Vitor C. Piro',
	  author_email='vitorpiro@gmail.com',
	  url='https://github.com/pirovc/metametamerge',
	  version='1.1',
      package_dir={'metametamerge': ''},
      packages=['metametamerge'],
      scripts=['MetaMetaMerge.py']
)
